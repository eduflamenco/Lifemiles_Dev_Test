package com.example.shunting.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShuntingYardApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShuntingYardApplication.class, args);
	}

}
