package com.example.shunting.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shunting.application.pojo.RequestPojo;
import com.example.shunting.application.process.IEvaluateProcess;

@RestController
@RequestMapping("/evaluate")
public class EvaluateController {
	
	private IEvaluateProcess<ResponseEntity<?>, RequestPojo> process;

	@Autowired
	public EvaluateController(@Qualifier("EvaluateProcess") IEvaluateProcess<ResponseEntity<?>, RequestPojo> process) {
		this.process = process;
	}
	
	@PostMapping("/expression")
	public ResponseEntity<?> evaluate(@RequestBody RequestPojo input) {
		
		return process.process(input); 
	}

}
