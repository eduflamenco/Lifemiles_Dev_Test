package com.example.shunting.application.evaluate;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import org.springframework.stereotype.Component;

import com.example.shunting.application.util.RoundDecimals;

@Component("EvaluateExpression")
public class EvaluateExpression implements IEvaluateExpression {
	
	private enum Operator
    {
        ADD(1), SUBTRACT(2), MULTIPLY(3), DIVIDE(4);
        final int precedence;
        Operator(int p) { precedence = p; }
    }
	
	private static Map<String, Operator> ops = new HashMap<String, Operator>() {{
        put("+", Operator.ADD);
        put("-", Operator.SUBTRACT);
        put("*", Operator.MULTIPLY);
        put("/", Operator.DIVIDE);
    }};
    
    private static boolean isHigerPrec(String op, String sub)
    {
        return (ops.containsKey(sub) && ops.get(sub).precedence >= ops.get(op).precedence);
    }
	
	@Override
	 public String evaluate(String infix)
	    {
	        StringBuilder postfix = new StringBuilder();
	        Stack<String> stack  = new Stack<String>();

	        for (String token : infix.split("\\s")) {
	            // operator
	            if (ops.containsKey(token)) {
	                while ( ! stack.isEmpty() && isHigerPrec(token, stack.peek()))
	                	postfix.append(stack.pop()).append(' ');
	                stack.push(token);

	            // digit
	            } else {
	            	postfix.append(token).append(' ');
	            }
	        }

	        while ( ! stack.isEmpty())
	        	postfix.append(stack.pop()).append(' ');

	        return postfix.toString();
	    }
	
	@Override
	public Double calculate(String postfix) {
		String pos = postfix.trim();
		Double result = 0.0;
		
	    String[] post = pos.split("\\s");   
	   
	    //Declaración de las pilas
	    Stack<String> E = new Stack<String> (); //Pila de numeros
	    Stack<String> P = new Stack<String> (); //Pila de signos

	 


	    //Añadir post (array) a la Pila de entrada (E)
	    for (int i = post.length - 1; i >= 0; i--) {
	      E.push(post[i]);
	    }

	    //Algoritmo de Evaluación Postfija
	    String operadores = "+-*/";
	    while (!E.isEmpty()) {
	      if (operadores.contains("" + E.peek())) {
	        P.push(evaluar(E.pop(), P.pop(), P.pop()) + "");
	      }else {
	        P.push(E.pop());
	      }
	    }
	    
	    result = Double.valueOf(RoundDecimals.roundDecimals(P.peek(), 2));
	    
	    return result;

	  }

	  private static Double evaluar(String op, String n2, String n1) {
	    Double num1 = Double.valueOf(n1);
	    Double num2 = Double.valueOf(n2);
	    if (op.equals("+")) return (num1 + num2);
	    if (op.equals("-")) return (num1 - num2);
	    if (op.equals("*")) return (num1 * num2);
	    if (op.equals("/")) return (num1 / num2);
	    return 0.0;
	  }
}
