package com.example.shunting.application.evaluate;

public interface IEvaluateExpression {

	public String evaluate(String infix);
	public Double calculate(String postfix);
	
}
