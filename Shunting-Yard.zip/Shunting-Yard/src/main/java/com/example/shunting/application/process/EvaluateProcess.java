package com.example.shunting.application.process;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.shunting.application.evaluate.IEvaluateExpression;
import com.example.shunting.application.pojo.ErrorPojo;
import com.example.shunting.application.pojo.RequestPojo;
import com.example.shunting.application.pojo.ResponsePojo;

@Service("EvaluateProcess")
public class EvaluateProcess implements IEvaluateProcess<ResponseEntity<?>, RequestPojo> {

	private static final String ERRORTEXT = "Some error ocurred while processing the expression";
	
	private IEvaluateExpression evaluate;
	private Logger log;

	@Autowired
	public EvaluateProcess(@Qualifier("EvaluateExpression") IEvaluateExpression evaluate) {
		this.evaluate = evaluate;
		log = LoggerFactory.getLogger(getClass());	
	}

	@Override
	public ResponseEntity<?> process(RequestPojo input) {
		ResponsePojo response = new ResponsePojo();
		ErrorPojo error = new ErrorPojo();
		String[] caracteres = input.getExp().split("");
		if (!caracteres[0].matches("[0-9]+")) {
			error.setMessage("The expression "+input.getExp()+ " is invalid");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
		}
		if (caracteres.length == 5 && Double.valueOf(caracteres[0]) < Double.valueOf(caracteres[4]) && caracteres[2].contentEquals("-")) {
			error.setMessage("The expression "+input.getExp()+ " is invalid");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
		}
		
		try {
			String postfix = evaluate.evaluate(input.getExp());
			Double value = evaluate.calculate(postfix);
			response.setInfix(input.getExp());
			response.setPostfix(postfix.trim());
			response.setResult(value);

		} catch (Exception e) {
			int errorLineNumber = 0;
			String methodName = "EvaluateProcess->process";
			if (e.getStackTrace() != null && e.getStackTrace().length > 0) {
				errorLineNumber = e.getStackTrace()[0].getLineNumber();
				methodName = e.getStackTrace()[0].getMethodName();
			}
			log.error("Some error ocurred while processing the expression", e, errorLineNumber, methodName);
			error.setMessage(ERRORTEXT);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
		}
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
}
