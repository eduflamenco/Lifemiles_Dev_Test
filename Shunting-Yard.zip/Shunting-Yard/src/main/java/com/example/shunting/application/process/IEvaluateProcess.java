package com.example.shunting.application.process;

public interface IEvaluateProcess <O,I> {
	
	public O  process(I input);

}
