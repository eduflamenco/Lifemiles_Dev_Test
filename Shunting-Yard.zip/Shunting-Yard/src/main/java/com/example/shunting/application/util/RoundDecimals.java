package com.example.shunting.application.util;

public class RoundDecimals 
{
	

	public static String roundDecimals(String valueIni, int decimals)
	{
		return roundDecimals(Double.parseDouble(valueIni), decimals);
	}
	
	public static String roundDecimals(Double valueIni, int decimals)
	{
		String valueRounded;
		
		switch (decimals) 
		{
			case 2: 
				valueRounded = String.format("%.2f", valueIni);
				break;
			case 0: 
				valueRounded = String.format("%.0f", valueIni);
				break;
			default: 
				StringBuilder sb = new StringBuilder("%");
				sb.append(decimals);
				sb.append("f");
				valueRounded = String.format(sb.toString(), valueIni);
		}
		
		return valueRounded;		
	}
	
}
