package com.example.shunting.application;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.shunting.application.pojo.RequestPojo;
import com.example.shunting.application.process.IEvaluateProcess;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class EvaluateProcessTest {
	
	@Autowired
	@Qualifier("EvaluateProcess")
	private IEvaluateProcess<ResponseEntity<?>, RequestPojo> process;

	@Test
	public void processSuccess() {
		String requestStr = "{\"exp\" : \"1 + 2.5 / 3 * 4\"}";
		ResponseEntity<?> response; 
		
		try {
			ObjectMapper mapper=new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			RequestPojo request = mapper.readValue(requestStr, RequestPojo.class);
			response = process.process(request);
			Assert.assertTrue("200".equals(response.getStatusCode().toString()));
		} catch (Exception e) {
			
		}
		
	}
	
	@Test
	public void processBadReq() {
		String requestStr = "{\"exp\" : \"-2+2+2\"}";
		ResponseEntity<?> response; 
		
		try {
			ObjectMapper mapper=new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			RequestPojo request = mapper.readValue(requestStr, RequestPojo.class);
			response = process.process(request);
			Assert.assertTrue("400".equals(response.getStatusCode().toString()));
		} catch (Exception e) {
			
		}
		
	}
	
	@Test
	public void processFail() {
		String requestStr = null;
		ResponseEntity<?> response; 
		
		try {
			ObjectMapper mapper=new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			RequestPojo request = mapper.readValue(requestStr, RequestPojo.class);
			response = process.process(request);
			Assert.assertTrue("500".equals(response.getStatusCode().toString()));
		} catch (Exception e) {
			
		}
		
	}

}
